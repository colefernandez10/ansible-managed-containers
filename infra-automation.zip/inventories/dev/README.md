#inventories/dev/inventory.yml
# This maps your container IPs (192.168.56.10 and 192.168.56.11) to Ansible hosts.
# later add it-ai and it-wealth when you spin up more containers.
