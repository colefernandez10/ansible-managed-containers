#Add department-specific variables:
#inventories/dev/group-vars/it-data.yaml
#inventories/dev/group-vars/it-finance.yml
